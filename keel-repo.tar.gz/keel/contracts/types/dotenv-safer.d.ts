declare module "dotenv-safer"
