// SPDX-License-Identifier: GPL-3.0

pragma solidity 0.8.24;

import "@openzeppelin/contracts-upgradeable/access/Ownable2StepUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

import "./BorrowerOperations.sol";
import "./dependencies/CheckContract.sol";
import "./dependencies/SendCollateral.sol";
import "./interfaces/IPCV.sol";
import "./token/IMUSD.sol";
import "./interfaces/IMUSDSavingsRate.sol";
import "./interfaces/IBTCFeeRecipient.sol";

/// @title Protocol Controlled Value
/// @notice The contract receives all interest and fees from the system and is
///         in charge of the bootstrap loan deposited to the stability pool.
///         The fees and interest are used to pay back the bootstrap loan or
///         deposited to the stability pool, as well as distributed to Tigris
///         as yield, depending on yield split parameters set by governance.
contract PCV is
    CheckContract,
    IPCV,
    Ownable2StepUpgradeable,
    ReentrancyGuardUpgradeable,
    SendCollateral
{
    using SafeERC20 for IMUSD;

    uint256 public constant BOOTSTRAP_LOAN = 1e26; // 100M mUSD

    uint256 public governanceTimeDelay;

    BorrowerOperations public borrowerOperations;
    IMUSD public musd;

    uint256 public debtToPay;
    bool public isInitialized;

    address public council;
    address public treasury;

    mapping(address => bool) public recipientsWhitelist;

    address public pendingCouncilAddress;
    address public pendingTreasuryAddress;
    uint256 public changingRolesInitiated;

    /// @dev MUSD fee recipient. Must implement IMUSDSavingsRate.
    address public feeRecipient;
    /// @dev Percentage of MUSD fees to be sent to feeRecipient. This split does
    ///      not apply to BTC fees.
    uint8 public feeSplitPercentage;
    uint8 public constant PERCENT_MAX = 100;

    /// @dev BTC redemption fees recipient. Must implement IBTCFeeRecipient.
    address public btcRecipient;

    /// @dev Tracks BTC received from StabilityPool liquidation gains.
    ///      This BTC is not distributed by distributeBTC().
    uint256 public stabilityPoolBTC;

    /// @dev Authorized address that can call distributeBTC().
    address public distributor;

    modifier onlyOwnerOrCouncilOrTreasury() {
        require(
            msg.sender == owner() ||
                msg.sender == council ||
                msg.sender == treasury,
            "PCV: caller must be owner or council or treasury"
        );
        _;
    }

    modifier onlyWhitelistedRecipient(address _recipient) {
        require(
            recipientsWhitelist[_recipient],
            "PCV: recipient must be in whitelist"
        );
        _;
    }

    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor() {
        _disableInitializers();
    }

    function initialize(uint256 _governanceTimeDelay) external initializer {
        __Ownable_init(msg.sender);

        require(
            _governanceTimeDelay <= 30 weeks,
            "Governance delay is too big"
        );
        governanceTimeDelay = _governanceTimeDelay;
    }

    function initializeV2() external reinitializer(2) {
        __ReentrancyGuard_init();
    }

    // solhint-disable-next-line ordering
    receive() external payable {
        if (
            address(borrowerOperations) != address(0) &&
            msg.sender == borrowerOperations.stabilityPoolAddress()
        ) {
            stabilityPoolBTC += msg.value;
        }
    }

    function setAddresses(
        address _borrowerOperations,
        address _musdTokenAddress
    ) external override onlyOwner {
        require(address(musd) == address(0), "PCV: contacts already set");

        checkContract(_borrowerOperations);
        checkContract(_musdTokenAddress);

        // slither-disable-start missing-zero-check
        borrowerOperations = BorrowerOperations(_borrowerOperations);
        musd = IMUSD(_musdTokenAddress);
        // slither-disable-end missing-zero-check

        emit BorrowerOperationsAddressSet(_borrowerOperations);
        emit MUSDTokenAddressSet(_musdTokenAddress);
    }

    function initializeDebt() external override onlyOwnerOrCouncilOrTreasury {
        require(!isInitialized, "PCV: already initialized");

        debtToPay = BOOTSTRAP_LOAN;
        isInitialized = true;
        borrowerOperations.mintBootstrapLoanFromPCV(BOOTSTRAP_LOAN);
        _depositToStabilityPool(BOOTSTRAP_LOAN);
    }

    function setFeeRecipient(
        address _feeRecipient
    ) external onlyOwnerOrCouncilOrTreasury {
        require(
            _feeRecipient != address(0),
            "PCV: Recipient cannot be the zero address."
        );
        feeRecipient = _feeRecipient;
        emit FeeRecipientSet(_feeRecipient);
    }

    function setBTCRecipient(
        address _btcRecipient
    ) external onlyOwnerOrCouncilOrTreasury {
        require(
            _btcRecipient != address(0),
            "PCV: BTC recipient cannot be the zero address."
        );
        btcRecipient = _btcRecipient;
        emit BTCRecipientSet(_btcRecipient);
    }

    /// @notice Sets the distributor address that can call distributeBTC().
    /// @param _distributor The address of the distributor bot. Can be set to
    ///        address(0) to disable the bot role; governance can still call
    ///        distributeBTC() directly.
    function setDistributor(
        address _distributor
    ) external onlyOwnerOrCouncilOrTreasury {
        // slither-disable-next-line missing-zero-check
        distributor = _distributor;
        emit DistributorSet(_distributor);
    }

    /// @notice Set the fee split percentage
    /// @param _feeSplitPercentage The fee split percentage
    /// @dev The fee split percentage must be between 0 and 100,
    ///      where 0 means all fees are sent for the protocol loan repayment and
    ///      100 means all fees are sent to the fee recipient.
    function setFeeSplit(
        uint8 _feeSplitPercentage
    ) external onlyOwnerOrCouncilOrTreasury {
        require(
            feeRecipient != address(0),
            "PCV must set fee recipient before setFeeSplit"
        );
        require(
            _feeSplitPercentage <= PERCENT_MAX,
            "PCV: Fee split must be at most 100"
        );
        feeSplitPercentage = _feeSplitPercentage;

        emit FeeSplitSet(_feeSplitPercentage);
    }

    function startChangingRoles(
        address _council,
        address _treasury
    ) external override onlyOwner {
        require(
            _council != council || _treasury != treasury,
            "PCV: these roles already set"
        );

        // solhint-disable-next-line not-rely-on-time
        changingRolesInitiated = block.timestamp;
        if (council == address(0) && treasury == address(0)) {
            // solhint-disable-next-line not-rely-on-time
            changingRolesInitiated -= governanceTimeDelay; // skip delay if no roles set
        }
        pendingCouncilAddress = _council;
        pendingTreasuryAddress = _treasury;
    }

    function cancelChangingRoles() external override onlyOwner {
        require(changingRolesInitiated != 0, "PCV: Change not initiated");

        changingRolesInitiated = 0;
        pendingCouncilAddress = address(0);
        pendingTreasuryAddress = address(0);
    }

    function finalizeChangingRoles() external override onlyOwner {
        require(changingRolesInitiated > 0, "PCV: Change not initiated");
        require(
            // solhint-disable-next-line not-rely-on-time
            block.timestamp >= changingRolesInitiated + governanceTimeDelay,
            "PCV: Governance delay has not elapsed"
        );

        council = pendingCouncilAddress;
        treasury = pendingTreasuryAddress;
        emit RolesSet(council, treasury);

        changingRolesInitiated = 0;
        pendingCouncilAddress = address(0);
        pendingTreasuryAddress = address(0);
    }

    function addRecipientToWhitelist(
        address _recipient
    ) external override onlyOwner {
        require(
            !recipientsWhitelist[_recipient],
            "PCV: Recipient has already been added to whitelist"
        );
        recipientsWhitelist[_recipient] = true;
        emit RecipientAdded(_recipient);
    }

    function removeRecipientFromWhitelist(
        address _recipient
    ) external override onlyOwner {
        require(
            recipientsWhitelist[_recipient],
            "PCV: Recipient is not in whitelist"
        );
        recipientsWhitelist[_recipient] = false;
        emit RecipientRemoved(_recipient);
    }

    /// @notice Distributes MUSD fees accumulated in this contract. The MUSD
    ///         comes from the borrowing fee, interest on debt, and refinance
    ///         fee. The fees are distributed based on the governance yield
    ///         split parameters. A portion of fees can be used to repay the
    ///         bootstrap loan or deposit to the stability pool. Another portion
    ///         of fees can be sent to Tigris as yield.
    function distributeMUSD() external override nonReentrant {
        uint256 musdBalance = musd.balanceOf(address(this));
        // If there are not enough tokens to distribute, do nothing.
        // This approach is less descriptive but more bot-friendly, which in the case
        // of this function is more appropriate.
        if (musdBalance == 0) {
            return;
        }

        uint256 distributedFees = (musdBalance * feeSplitPercentage) /
            PERCENT_MAX;
        uint256 protocolLoanRepayment = musdBalance - distributedFees;
        uint256 stabilityPoolDeposit = 0;

        // check for excess to deposit into the stability pool
        if (protocolLoanRepayment > debtToPay) {
            stabilityPoolDeposit = protocolLoanRepayment - debtToPay;
            protocolLoanRepayment = debtToPay;
        }

        _repayDebt(protocolLoanRepayment);

        if (stabilityPoolDeposit > 0) {
            _depositToStabilityPool(stabilityPoolDeposit);
        }

        if (feeRecipient != address(0) && distributedFees > 0) {
            musd.forceApprove(feeRecipient, distributedFees);
            IMUSDSavingsRate(feeRecipient).receiveProtocolYield(
                distributedFees
            );

            // slither-disable-next-line reentrancy-events
            emit PCVDistribution(feeRecipient, distributedFees);
        }
    }

    /// @notice Distributes accumulated BTC from redemption fees to Tigris as
    ///         yield. Only callable by the distributor bot, owner, council, or
    ///         treasury. BTC from StabilityPool liquidation gains (tracked by
    ///         stabilityPoolBTC) is excluded from distribution.
    function distributeBTC() external override nonReentrant {
        require(
            msg.sender == distributor ||
                msg.sender == owner() ||
                msg.sender == council ||
                msg.sender == treasury,
            "PCV: caller not authorized"
        );

        uint256 collateralAmount = address(this).balance - stabilityPoolBTC;
        // If there is not enough collateral to distribute, do nothing.
        // This approach is less descriptive but more bot-friendly, which in the case
        // of this function is more appropriate.
        if (collateralAmount == 0) {
            return;
        }

        require(btcRecipient != address(0), "PCV: BTC recipient not set");

        _sendCollateral(btcRecipient, collateralAmount);
        IBTCFeeRecipient(btcRecipient).receiveProtocolYieldInBTC(
            collateralAmount
        );
        // slither-disable-next-line reentrancy-events
        emit PCVDistributionBTC(btcRecipient, collateralAmount);
    }

    /// @notice Withdraws BTC that was claimed from the StabilityPool and is
    ///         being held in this contract, tracked by stabilityPoolBTC. This
    ///         is distinct from withdrawFromStabilityPool(), which pulls MUSD
    ///         and BTC gains out of the StabilityPool contract itself (reducing
    ///         PCV's deposit position). This function sends BTC that has
    ///         already been claimed and is sitting in PCV's balance.
    /// @param _amount The amount of stability BTC to withdraw
    /// @param _recipient The whitelisted recipient address
    function withdrawStabilityBTC(
        uint256 _amount,
        address _recipient
    )
        external
        onlyOwnerOrCouncilOrTreasury
        onlyWhitelistedRecipient(_recipient)
    {
        require(
            _amount <= stabilityPoolBTC,
            "PCV: amount exceeds stability BTC"
        );
        emit StabilityBTCWithdrawn(_recipient, _amount);
        stabilityPoolBTC -= _amount;
        _sendCollateral(_recipient, _amount);
    }

    /// @notice Allows anyone to deposit MUSD to the stability pool. Note that
    ///         the tokens will be deposited as a PCV deposit, so the depositor
    ///         is donating them to the PCV. Do not call this function unless
    ///         you want to donate your tokens!
    function depositToStabilityPool(uint256 _amount) external {
        musd.safeTransferFrom(msg.sender, address(this), _amount);
        _depositToStabilityPool(_amount);
    }

    /// @notice Withdraws collateral and/or MUSD from the stability pool to the
    ///         provided recipient address. The recipient address must have been
    ///         whitelisted beforehand. The function is used for rebalancing the
    ///         stability pool after liquidations.
    function withdrawFromStabilityPool(
        uint256 _amount,
        address _recipient
    )
        external
        onlyOwnerOrCouncilOrTreasury
        onlyWhitelistedRecipient(_recipient)
    {
        uint256 btcBefore = stabilityPoolBTC;
        uint256 musdBefore = musd.balanceOf(address(this));

        IStabilityPool(borrowerOperations.stabilityPoolAddress())
            .withdrawFromSP(_amount);

        uint256 btcClaimed = stabilityPoolBTC - btcBefore;
        uint256 musdChange = musd.balanceOf(address(this)) - musdBefore;

        uint256 debtRepayment = _repayDebt(musdChange);
        uint256 excessMusd = musdChange - debtRepayment;

        // Send BTC collateral to recipient. The BTC arrived via receive()
        // which incremented stabilityPoolBTC, so decrement it here.
        if (btcClaimed > 0) {
            // Stability Pool and BorrowerOperations are trusted contracts.
            // slither-disable-next-line reentrancy-benign,reentrancy-no-eth
            stabilityPoolBTC -= btcClaimed;
            _sendCollateral(_recipient, btcClaimed);
        }

        // Send excess MUSD to recipient (after debt repayment)
        if (excessMusd > 0) {
            musd.safeTransfer(_recipient, excessMusd);
        }

        // slither-disable-next-line reentrancy-events
        emit PCVWithdrawSP(msg.sender, musdChange, btcClaimed);
    }

    function _repayDebt(uint _repayment) internal returns (uint256) {
        if (_repayment > debtToPay) {
            _repayment = debtToPay;
        }

        if (_repayment > 0 && debtToPay > 0) {
            debtToPay -= _repayment;
            borrowerOperations.burnDebtFromPCV(_repayment);

            // slither-disable-next-line reentrancy-events
            emit PCVDebtPayment(_repayment);
            return _repayment;
        }

        return 0;
    }

    function _depositToStabilityPool(uint256 _amount) internal {
        musd.forceApprove(borrowerOperations.stabilityPoolAddress(), _amount);

        IStabilityPool(borrowerOperations.stabilityPoolAddress()).provideToSP(
            _amount
        );

        // slither-disable-next-line reentrancy-events
        emit PCVDepositSP(msg.sender, _amount);
    }
}
