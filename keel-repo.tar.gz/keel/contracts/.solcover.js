module.exports = {
  configureYulOptimizer: true,
}
